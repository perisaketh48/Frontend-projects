package Astro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TribnAstroNirugunaApplicationTests {

	@Test
	void contextLoads() {
	}

}
