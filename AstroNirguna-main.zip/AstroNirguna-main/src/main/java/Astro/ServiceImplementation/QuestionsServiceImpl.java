package Astro.ServiceImplementation;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Astro.Model.Appointment;
import Astro.Model.QuestionsModel;
import Astro.Model.User;
import Astro.Repository.AppointmentRepository;
import Astro.Repository.QuestionsRepository;
import Astro.Service.QuestionsService;


@Service
public class QuestionsServiceImpl implements QuestionsService {
	
	@Autowired
    private QuestionsRepository questionsRepository;
	
	@Autowired
    private AppointmentRepository appointmentRepository;

	
	@Override
    public Optional<QuestionsModel> getQuestionsById(int id) {
        return questionsRepository.findById(id);
    }

    @Override
    public List<QuestionsModel> getAllQuestions() {
        return questionsRepository.findAll();
    }

    @Override
    public void deleteAllQuestions(int id) {
    	questionsRepository.deleteById(id);
    }

    @Override
    public QuestionsModel updateQuestionsUserById(int id, QuestionsModel questionsModel) {
        if (questionsRepository.existsById(id)) {
        	questionsModel.setId(id);
            return questionsRepository.save(questionsModel);
        } else {
            return null; // or throw exception
        }
    }

	@Override
	public QuestionsModel saveQuestions(int appointment_id, QuestionsModel questionsModel) {
		Appointment appointment = appointmentRepository.findById(appointment_id).orElseThrow(()->new IllegalArgumentException("project not found with id: "+appointment_id ));


		if(appointment != null) {
			questionsModel.setAppointment(appointment);;
		
		return questionsRepository.save(questionsModel);
		}
		return null;
	} 
}

	