package Astro.ServiceImplementation;

import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Astro.Model.UserDetails;
import Astro.Repository.UserDetailsRepository;
import Astro.Service.UserDetailsService;

@Service
public class UserDetailsServiceImpl implements UserDetailsService{

	@Autowired
    private UserDetailsRepository userRepository;

    
    @Override
    public void deleteUser(int id) {
        userRepository.deleteById(id);
    }

    @Override
    public UserDetails getUserById(int id) {
        Optional<UserDetails> optionalUser = userRepository.findById(id);
        return optionalUser.orElse(null);
    }

    @Override
    public List<UserDetails> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public UserDetails updateUser(UserDetails user) {
        return userRepository.save(user);
    }

	@Override
	public void saveUser(int id, String placeOfBirth, LocalTime timeOfBirth, LocalDate dateOfBirth, String name, byte[] photoBytes) {
		
		UserDetails userDetails = new UserDetails(id, placeOfBirth, timeOfBirth, dateOfBirth, name, photoBytes);
		userDetails.setId(id);
		userDetails.setDateOfBirth(dateOfBirth);
		userDetails.setTimeOfBirth(timeOfBirth);
		userDetails.setPlaceOfBirth(placeOfBirth);
		userDetails.setPhoto(photoBytes);
		userDetails.setName(name);
        return;
    }

	


		
}
