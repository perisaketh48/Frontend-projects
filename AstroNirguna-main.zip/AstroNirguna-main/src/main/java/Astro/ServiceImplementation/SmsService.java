package Astro.ServiceImplementation;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class SmsService {

	@Value("${twilio.account.sid}")
    private String twilioAccountSid;

    @Value("${twilio.auth.token}")
    private String twilioAuthToken;

    @Value("${twilio.phone.number}")
    private String twilioPhoneNumber;

    public void sendOtpSms(String phoneNumber, String otp) {
        // Integration with Twilio or any other SMS service provider
        // Send SMS containing OTP to the provided phoneNumber
    }

}
