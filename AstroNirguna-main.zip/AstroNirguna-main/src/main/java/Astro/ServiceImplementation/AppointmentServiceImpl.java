package Astro.ServiceImplementation;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Astro.Model.Appointment;
import Astro.Model.User;
import Astro.Repository.AppointmentRepository;
import Astro.Repository.UserRepository;
import Astro.Service.AppointmentService;


@Service
public class AppointmentServiceImpl implements AppointmentService{

	
		@Autowired
	    private AppointmentRepository appointmentRepository;
		
		@Autowired
		private UserRepository userRepository;

		
		@Override
	    public Optional<Appointment> getAppointmentById(int id) {
	        return appointmentRepository.findById(id);
	    }

	    @Override
	    public List<Appointment> getAllAppointment() {
	        return appointmentRepository.findAll();
	    }

	    @Override
	    public void deleteAppointment(int id) {
	    	appointmentRepository.deleteById(id);
	    }

	    @Override
	    public Appointment updateAppointmentById(int id, Appointment appointment) {
	        if (appointmentRepository.existsById(id)) {
	        	appointment.setId(id);
	            return appointmentRepository.save(appointment);
	        } else {
	            return null; // or throw exception
	        }
	    }

		@Override
		public Appointment saveAppointment(int id, Appointment appointment) {
			
			User user = userRepository.findById(id).orElseThrow(()->new IllegalArgumentException("project not found with id: "+id ));
		
			
			if(user != null) {
				 appointment.setUser(user);
				 
				 return appointmentRepository.save(appointment);
			}
			return null;
		} 
}
