package Astro.ServiceImplementation;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import Astro.Model.User;
import Astro.Repository.UserRepository;
import Astro.Service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
    private UserRepository userRepository;

    @Autowired
    private SmsService smsService;

    @Override
    public String registerUser(String phoneNumber) {
        User user = userRepository.findByPhoneNumber(phoneNumber);
        String otp = generateOtp();
        LocalDateTime otpExpiry = LocalDateTime.now().plusMinutes(5); // 5 minutes expiry
        if (user == null) {
        	user = new User();
        	user.setPhoneNumber(phoneNumber);
        	user.setOtp(otp);
        	user.setOtpExpiry(otpExpiry);
            userRepository.save(user);
        } else {
        	user.setOtp(otp);
        	user.setOtpExpiry(otpExpiry);
            userRepository.save(user);
        }
        smsService.sendOtpSms(phoneNumber, otp);
        return "OTP sent successfully";
    }

    @Override
    public String verifyOtp(String phoneNumber, String otp) {
        User user = userRepository.findByPhoneNumber(phoneNumber);
        if (user == null) {
            return "User not registered";
        }
        if (!user.getOtp().equals(otp)) {
            return "Invalid OTP";
        }
        if (user.getOtpExpiry().isBefore(LocalDateTime.now())) {
            return "OTP expired";
        }
        return "OTP verified successfully";
    }

    private String generateOtp() {
    	// Generate a random 4-digit OTP
        Random random = new Random();
        int otp = 1000 + random.nextInt(9000);
        return String.valueOf(otp);
    }
    }
	    

