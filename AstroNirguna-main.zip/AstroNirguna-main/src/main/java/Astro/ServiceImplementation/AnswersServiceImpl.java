package Astro.ServiceImplementation;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Astro.Model.AnswersModel;
import Astro.Model.QuestionsModel;
import Astro.Model.User;
import Astro.Repository.AnswersRepository;
import Astro.Repository.QuestionsRepository;
import Astro.Service.AnswersService;

@Service
public class AnswersServiceImpl implements AnswersService{

	@Autowired
    private AnswersRepository answersRepository;
	
	@Autowired
    private QuestionsRepository questionsRepository;
	
	@Override
	public Object saveAnswers(int id, AnswersModel answersModel) {
		QuestionsModel questionsModel = questionsRepository.findById(id).orElseThrow(()->new IllegalArgumentException("project not found with id: "+id ));
		
		
		if(questionsModel != null) {
			answersModel.setId(id);;
			 
			return answersRepository.save(answersModel);
		}
		return null;
	} 
	
	@Override
	public List<AnswersModel> getAllAnswers() {
		// TODO Auto-generated method stub
		return answersRepository.findAll();
	}

	@Override
	public AnswersModel updateAnswersUserById(int id, AnswersModel answersModel) {
		 if (answersRepository.existsById(id)) {
	        	answersModel.setId(id);
	            return answersRepository.save(answersModel);
	        } else {
	            return null; // or throw exception
	        }
	}

	@Override
	public void deleteAllAnswers(int id) {
		// TODO Auto-generated method stub
		answersRepository.deleteById(id);
	}

	@Override
	public Optional<AnswersModel> getAnswersById(int id) {
		// TODO Auto-generated method stub
		return answersRepository.findById(id);
	}

}
