package Astro.Model;

import java.util.List;

import org.hibernate.annotations.DynamicUpdate;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;

@Entity
@DynamicUpdate
public class QuestionsModel {
	
	 @Id
	   // @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private int id;

	    @OneToOne
	    private AnswersModel answersModel;

	    @ManyToOne
	    @JoinColumn(name = "appointment_id", referencedColumnName = "id")
	    private Appointment appointment;



 
	public AnswersModel getAnswersModel() {
			return answersModel;
		}
		public void setAnswersModel(AnswersModel answersModel) {
			this.answersModel = answersModel;
		}
		public Appointment getAppointment() {
			return appointment;
		}
		public void setAppointment(Appointment appointment) {
			this.appointment = appointment;
		}
	@Column(length = 100, nullable = false)
	private String question1;
	
	@Column(length = 100, nullable = false)
    private String question2;
	
	@Column(length = 100, nullable = false)
    private String question3;
	
	public String getQuestion1() {
		return question1;
	}
	public void setQuestion1(String question1) {
		this.question1 = question1;
	}
	public String getQuestion2() {
		return question2;
	}
	public void setQuestion2(String question2) {
		this.question2 = question2;
	}
	public String getQuestion3() {
		return question3;
	}
	public void setQuestion3(String question3) {
		this.question3 = question3;
	}
	@Override
	public String toString() {
		return "QuestionsModel [question1=" + question1 + ", question2=" + question2 + ", question3=" + question3 + "]";
	}
	public Object map(Object object) {
		// TODO Auto-generated method stub
		return null;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	

}
