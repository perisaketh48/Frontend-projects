package Astro.Model;

import org.hibernate.annotations.DynamicUpdate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;

@Entity
@DynamicUpdate
public class AnswersModel {

	@Id
    private int id;

    @OneToOne
    private QuestionsModel questionsModel;

    
	@Column(length = 100000, nullable = false)
	private String answer1;
	
	@Column(length = 100000, nullable = false)
    private String answer2;
	
	@Column(length = 100000, nullable = false)
    private String answer3;
	

	@Column(length = 100000, nullable = false)
	private String remedies;
	
	public QuestionsModel getQuestionsModel() {
		return questionsModel;
	}
	public void setQuestionsModel(QuestionsModel questionsModel) {
		this.questionsModel = questionsModel;
	}
	@Column(length = 100000, nullable = false)
    private String poojas;
	
		
	public String getAnswer1() {
		return answer1;
	}
	public void setAnswer1(String answer1) {
		this.answer1 = answer1;
	}
	public String getAnswer2() {
		return answer2;
	}
	public void setAnswer2(String answer2) {
		this.answer2 = answer2;
	}
	public String getAnswer3() {
		return answer3;
	}
	public void setAnswer3(String answer3) {
		this.answer3 = answer3;
	}
	
	@Override
	public String toString() {
		return "AnswersModel [id=" + id + ", answer1=" + answer1 + ", answer2=" + answer2 + ", answer3=" + answer3
				+ ", remedies=" + remedies + ", poojas=" + poojas + "]";
	}
	public String getRemedies() {
		return remedies;
	}
	public void setRemedies(String remedies) {
		this.remedies = remedies;
	}
	public String getPoojas() {
		return poojas;
	}
	public void setPoojas(String poojas) {
		this.poojas = poojas;
	}
	public Object map(Object object) {
		// TODO Auto-generated method stub
		return null;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	

}
