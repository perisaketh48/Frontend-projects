package Astro.Model;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.hibernate.annotations.DynamicUpdate;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;

@Entity
@DynamicUpdate
public class Appointment {

    @Id
    //@GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @OneToMany(mappedBy = "appointment")
    private List<QuestionsModel> questionsModel;

    private String appointmentType;
    private LocalTime appointmentTime;
    @Column(name = "appointment_date", columnDefinition = "DATE")
    private LocalDate appointmentDate;

    @Override
    public String toString() {
        return "Appointment [id=" + id + ", appointmentType=" + appointmentType + ", appointmentTime=" + appointmentTime
                + ", appointmentDate=" + appointmentDate + "]";
    }

    public String getAppointmentType() {
        return appointmentType;
    }

    public void setAppointmentType(String appointmentType) {
        this.appointmentType = appointmentType;
    }

    public LocalTime getAppointmentTime() {
        return appointmentTime;
    }

    public void setAppointmentTime(LocalTime localTime) {
        this.appointmentTime = localTime;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public List<QuestionsModel> getQuestionsModel() {
		return questionsModel;
	}

	public void setQuestionsModel(List<QuestionsModel> questionsModel) {
		this.questionsModel = questionsModel;
	}

	public LocalDate getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(LocalDate appointmentDate) {
        this.appointmentDate = appointmentDate;
    }
}
