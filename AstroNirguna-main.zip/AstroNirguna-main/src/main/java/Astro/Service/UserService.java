package Astro.Service;

import java.util.List;

import Astro.Model.User;

public interface UserService {
	 String registerUser(String phoneNumber);
	 
	    String verifyOtp(String phoneNumber, String otp);

}
