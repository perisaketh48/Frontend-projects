package Astro.Service;

import java.util.List;
import java.util.Optional;

import Astro.Model.QuestionsModel;



public interface QuestionsService {

	Object saveQuestions(int appointment_id, QuestionsModel questionsModel);

	List<QuestionsModel> getAllQuestions();



	QuestionsModel updateQuestionsUserById(int id, QuestionsModel questionsModel);

	void deleteAllQuestions(int id);

	Optional<QuestionsModel> getQuestionsById(int id);

}
