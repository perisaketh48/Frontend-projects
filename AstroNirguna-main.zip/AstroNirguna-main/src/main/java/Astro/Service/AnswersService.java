package Astro.Service;

import java.util.List;
import java.util.Optional;

import Astro.Model.AnswersModel;


public interface AnswersService {

	Object saveAnswers(int id, AnswersModel answersModel);

	List<AnswersModel> getAllAnswers();



	AnswersModel updateAnswersUserById(int id, AnswersModel AnswersModel);

	void deleteAllAnswers(int id);

	Optional<AnswersModel> getAnswersById(int id);

}
