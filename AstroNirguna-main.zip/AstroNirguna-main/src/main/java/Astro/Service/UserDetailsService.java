package Astro.Service;

import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import Astro.Model.UserDetails;

public interface UserDetailsService {

	
    void deleteUser(int id);
    UserDetails getUserById(int id);
    List<UserDetails> getAllUsers();
    UserDetails updateUser(UserDetails user);
	
	
	//void saveUser(String placeOfBirth, LocalTime timeOfBirth, LocalDate dateOfBirth, String name, byte[] photoBytes);
	void saveUser(int id, String placeOfBirth, LocalTime timeOfBirth, LocalDate dateOfBirth, String name, byte[] photoBytes);

}
