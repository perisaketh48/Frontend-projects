package Astro.Service;

import java.util.List;
import java.util.Optional;

import Astro.Model.Appointment;

public interface AppointmentService {

	Appointment saveAppointment(int id, Appointment appointment);

	void deleteAppointment(int id);

	Optional<Appointment> getAppointmentById(int id);

	List<Appointment> getAllAppointment();

	Appointment updateAppointmentById(int id, Appointment appointment);

}
