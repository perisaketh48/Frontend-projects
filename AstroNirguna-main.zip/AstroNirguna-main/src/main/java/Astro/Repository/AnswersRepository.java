package Astro.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import Astro.Model.AnswersModel;

@Repository
public interface AnswersRepository extends JpaRepository<AnswersModel, Integer>{

}
