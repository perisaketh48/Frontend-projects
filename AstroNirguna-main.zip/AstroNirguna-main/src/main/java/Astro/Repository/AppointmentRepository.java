package Astro.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import Astro.Model.Appointment;


public interface AppointmentRepository extends JpaRepository<Appointment, Integer>{

}
