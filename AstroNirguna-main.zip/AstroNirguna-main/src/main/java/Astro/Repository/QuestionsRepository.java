package Astro.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import Astro.Model.QuestionsModel;


@Repository
public interface QuestionsRepository extends JpaRepository<QuestionsModel, Integer>{

}
