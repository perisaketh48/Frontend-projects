package Astro.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import Astro.Model.QuestionsModel;

import Astro.Service.QuestionsService;


@RestController
@RequestMapping("/api/astro")
public class QuestionsController {
	
    @Autowired
    private QuestionsService questionsService;

    @PostMapping("/saveQuestions/{appointment_id}")
	 public ResponseEntity<String> saveQuestions(@PathVariable int appointment_id, @RequestBody QuestionsModel questionsModel) {
        try {
            // Save the personal details
        	questionsService.saveQuestions(appointment_id, questionsModel);
            return new ResponseEntity<>("questions  saved successfully", HttpStatus.CREATED);
        } catch (Exception e) {
            // If an error occurs during saving, return an error response
            return new ResponseEntity<>("Failed to save  questions", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    
} 
   
    @GetMapping("/getQuestionsById/{id}")
    public ResponseEntity<QuestionsModel> getQuestionsById(@PathVariable int id) {
    	Optional<QuestionsModel> questionsModel = questionsService.getQuestionsById(id);
        return questionsModel.map(details -> new ResponseEntity<>(details, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @GetMapping("/getAllQuestions")
    public ResponseEntity<List<QuestionsModel>> getAllQuestions() {
        List<QuestionsModel> questionsList = questionsService.getAllQuestions();
        return new ResponseEntity<>(questionsList, HttpStatus.OK);
    }

    @DeleteMapping("/deleteQuestionsById/{id}")
    public ResponseEntity<Void> deleteAllQuestions(@PathVariable int id) {
    	questionsService.deleteAllQuestions(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PutMapping("/updateQuestionsById/{id}")
    public ResponseEntity<QuestionsModel> updateQuestionsUserById(@PathVariable int id,
            @RequestBody QuestionsModel questionsModel) {
    	QuestionsModel updateQuestionsUserById = questionsService.updateQuestionsUserById(id, questionsModel);
        if (updateQuestionsUserById != null) {
            return new ResponseEntity<>(updateQuestionsUserById, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

}
