package Astro.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import Astro.Model.User;
import Astro.Service.UserService;

@RestController
@RequestMapping("/api/astro")
public class UserController {

	@Autowired
    private UserService userService;

	@PostMapping("/authenticate")
    public ResponseEntity<String> authenticate(@RequestParam String phoneNumber, @RequestParam(required = false) String otp) {
        try {
            if (otp == null) {
                // Registration scenario
                String result = userService.registerUser(phoneNumber);
                return new ResponseEntity<>(result, HttpStatus.OK);
            } else {
                // OTP verification scenario
                String result = userService.verifyOtp(phoneNumber, otp);
                return new ResponseEntity<>(result, HttpStatus.OK);
            }
        } catch (Exception e) {
            return new ResponseEntity<>("Failed: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    }

