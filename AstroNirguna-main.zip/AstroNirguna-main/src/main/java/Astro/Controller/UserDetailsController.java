package Astro.Controller;

import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import Astro.Model.UserDetails;
import Astro.Service.UserDetailsService;

@RestController
@RequestMapping("/api/astro")
public class UserDetailsController {
    
    @Autowired
    private UserDetailsService userService;
    @PostMapping("/add/{id}")
    public ResponseEntity<String> addUser(
            @PathVariable int id,
            @RequestPart("placeOfBirth") String placeOfBirth,
            @RequestPart("timeOfBirth") String timeOfBirthString, // Receive time as string
            @RequestPart("dateOfBirth") String dateOfBirthString, // Receive date as string
            @RequestPart("photo") MultipartFile photo,
            @RequestPart("name") String name) {    
        
        try {
            // Parse time string to LocalTime
            LocalTime timeOfBirth = LocalTime.parse(timeOfBirthString);

            // Parse date string to LocalDate
            LocalDate dateOfBirth = LocalDate.parse(dateOfBirthString);

            // Convert files to byte arrays
            byte[] photoBytes = photo.getBytes();

            // Save user details.
            userService.saveUser(id, placeOfBirth, timeOfBirth, dateOfBirth, name, photoBytes);
            
            return ResponseEntity.ok("Saved user details successfully");
        } catch (IOException e) {
            e.printStackTrace();
            // Handle the exception or return an error message
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error saving user details");
        }       
    }

    // Method to parse time string to LocalTime
    private LocalTime parseLocalTime(String timeString) {
        // Define a DateTimeFormatter for flexible time parsing
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("[h:mm a][H:mm]");

        // Parse the time string to LocalTime
        return LocalTime.parse(timeString, formatter);
    }


    @DeleteMapping("/delete/{id}")
    public void deleteUser(@PathVariable int id) {
        userService.deleteUser(id);
    }

    @GetMapping("/{id}")
    public UserDetails getUserById(@PathVariable int id) {
        return userService.getUserById(id);
    }

    @GetMapping("/all")
    public List<UserDetails> getAllUsers() {
        return userService.getAllUsers();
    }

    @PutMapping("/update")
    public UserDetails updateUser(@RequestBody UserDetails user) {
        return userService.updateUser(user);
    }
}
