package Astro.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import Astro.Model.AnswersModel;
import Astro.Repository.AnswersRepository;
import Astro.Service.AnswersService;

@RestController
@RequestMapping("/api/astro")
public class AnswersController {

	 @Autowired
	    private AnswersRepository answersRepository;

	 @PostMapping("/saveAnswers/{questionsModel_id}")
	    public ResponseEntity<String> saveAnswers(@RequestBody AnswersModel answersModel) {
	        try {
	            // Save the answers using the repository
	            answersRepository.save(answersModel);
	            return new ResponseEntity<>("Answers saved successfully", HttpStatus.CREATED);
	        } catch (Exception e) {
	            // If an error occurs during saving, return an error response
	            return new ResponseEntity<>("Failed to save answers", HttpStatus.INTERNAL_SERVER_ERROR);
	        }
	    } 
	   
	 @GetMapping("/getAnswersById/{id}")
	    public ResponseEntity<AnswersModel> getAnswersById(@PathVariable int id) {
	        Optional<AnswersModel> answersModelOptional = answersRepository.findById(id);
	        return answersModelOptional.map(answersModel -> new ResponseEntity<>(answersModel, HttpStatus.OK))
	                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
	    }

	    @GetMapping("/getAllAnswers")
	    public ResponseEntity<List<AnswersModel>> getAllAnswers() {
	        List<AnswersModel> answersList = answersRepository.findAll();
	        return new ResponseEntity<>(answersList, HttpStatus.OK);
	    }

	    @DeleteMapping("/deleteAnswersById/{id}")
	    public ResponseEntity<Void> deleteAnswersById(@PathVariable int id) {
	        answersRepository.deleteById(id);
	        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	    }

	    @PutMapping("/updateAnswersById/{id}")
	    public ResponseEntity<AnswersModel> updateAnswersUserById(@PathVariable int id,
	            @RequestBody AnswersModel answersModel) {
	    	AnswersModel updateAnswersUserById = ((AnswersService) answersRepository).updateAnswersUserById(id, answersModel);
	        if (updateAnswersUserById != null) {
	            return new ResponseEntity<>(updateAnswersUserById, HttpStatus.OK);
	        } else {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	        }
	    }
}
