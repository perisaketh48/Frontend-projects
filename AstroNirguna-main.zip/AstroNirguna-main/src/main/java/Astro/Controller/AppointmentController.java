package Astro.Controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import Astro.Model.Appointment;
import Astro.Service.AppointmentService;


@RestController
@RequestMapping("/api/astro")
public class AppointmentController {

	@Autowired
    private AppointmentService appointmentService;

	
	  
	@PostMapping("/saveAppointment/{id}")
    public ResponseEntity<String> saveAppointment(@PathVariable int id, @RequestBody Appointment appointment
            ) {
		try {
	        // Save the appointment directly
	        appointmentService.saveAppointment(id, appointment);
	        return new ResponseEntity<>("Appointment saved successfully", HttpStatus.CREATED);
	    } catch (Exception e) {
	        // If an error occurs during saving, return an error response
	        return new ResponseEntity<>("Failed to save Appointment", HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	}

	@GetMapping("/getAppointmentById/{userId}")
    public ResponseEntity<Appointment> getAppointmentById(@PathVariable int id) {
    	Optional<Appointment> appointment = appointmentService.getAppointmentById(id);
        return appointment.map(details -> new ResponseEntity<>(details, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @GetMapping("/getAllAppointments")
    public ResponseEntity<List<Appointment>> getAllAppointment() {
        List<Appointment> appointmentList = appointmentService.getAllAppointment();
        return new ResponseEntity<>(appointmentList, HttpStatus.OK);
    }

    @DeleteMapping("/deleteAppointmentById/{id}")
    public ResponseEntity<Void> deleteAppointment(@PathVariable int id) {
    	appointmentService.deleteAppointment(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PutMapping("/updateAppointmentById/{id}")
    public ResponseEntity<Appointment> updateAppointmentById(@PathVariable int id,
            @RequestBody Appointment appointment) {
    	Appointment updateAppointmentById = appointmentService.updateAppointmentById(id, appointment);
        if (updateAppointmentById != null) {
            return new ResponseEntity<>(updateAppointmentById, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
